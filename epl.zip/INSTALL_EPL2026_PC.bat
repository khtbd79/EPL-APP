@echo off
setlocal EnableDelayedExpansion
title EPL 2026 MATCH CENTER - PC Installer
color 0A
cd /d "%~dp0"

echo ====================================================================
echo             EPL 2026 MATCH CENTER - WINDOWS PC INSTALLER
echo                         1-Click Setup Wizard
echo ====================================================================
echo.
echo [1/4] Checking installer files...
if not exist "index.html" (
    echo [ERROR] index.html not found!
    echo Please make sure you have EXTRACTED the ZIP file before running.
    echo.
    pause
    exit /b 1
)

set "INSTALL_DIR=%LOCALAPPDATA%\Programs\EPL2026"
echo [2/4] Installing application to:
echo       "%INSTALL_DIR%"
if not exist "%INSTALL_DIR%" mkdir "%INSTALL_DIR%"

echo [3/4] Copying files to program directory...
copy /Y "index.html" "%INSTALL_DIR%\index.html" >nul
if exist "favicon.ico" (
    copy /Y "favicon.ico" "%INSTALL_DIR%\icon.ico" >nul
) else if exist "icon.png" (
    copy /Y "icon.png" "%INSTALL_DIR%\icon.png" >nul
)

:: Create standalone runner script inside the installed directory
(
echo @echo off
echo cd /d "%%~dp0"
echo set "HTML_PATH=%%~dp0index.html"
echo set "FILE_URL=file:///%%HTML_PATH:\=/%%"
echo :: Try Microsoft Edge in standalone app window mode
echo if exist "%%ProgramFiles(x86)%%\Microsoft\Edge\Application\msedge.exe" ^(
echo     start "" "%%ProgramFiles(x86)%%\Microsoft\Edge\Application\msedge.exe" --app="%%FILE_URL%%" --window-size=1540,920
echo     exit /b
echo ^)
echo if exist "%%ProgramFiles%%\Microsoft\Edge\Application\msedge.exe" ^(
echo     start "" "%%ProgramFiles%%\Microsoft\Edge\Application\msedge.exe" --app="%%FILE_URL%%" --window-size=1540,920
echo     exit /b
echo ^)
echo if exist "%%LocalAppData%%\Microsoft\Edge\Application\msedge.exe" ^(
echo     start "" "%%LocalAppData%%\Microsoft\Edge\Application\msedge.exe" --app="%%FILE_URL%%" --window-size=1540,920
echo     exit /b
echo ^)
echo :: Try Google Chrome in standalone app window mode
echo if exist "%%ProgramFiles%%\Google\Chrome\Application\chrome.exe" ^(
echo     start "" "%%ProgramFiles%%\Google\Chrome\Application\chrome.exe" --app="%%FILE_URL%%" --window-size=1540,920
echo     exit /b
echo ^)
echo if exist "%%ProgramFiles(x86)%%\Google\Chrome\Application\chrome.exe" ^(
echo     start "" "%%ProgramFiles(x86)%%\Google\Chrome\Application\chrome.exe" --app="%%FILE_URL%%" --window-size=1540,920
echo     exit /b
echo ^)
echo if exist "%%LocalAppData%%\Google\Chrome\Application\chrome.exe" ^(
echo     start "" "%%LocalAppData%%\Google\Chrome\Application\chrome.exe" --app="%%FILE_URL%%" --window-size=1540,920
echo     exit /b
echo ^)
echo :: Fallback default browser
echo start "" "%%HTML_PATH%%"
echo exit /b
) > "%INSTALL_DIR%\run_app.bat"

:: Create VBScript launcher for silent launch (no black command prompt)
(
echo Set WshShell = CreateObject^("WScript.Shell"^)
echo strDir = CreateObject^("Scripting.FileSystemObject"^).GetParentFolderName^(WScript.ScriptFullName^)
echo WshShell.Run "cmd /c """ ^& strDir ^& "\run_app.bat""", 0, False
) > "%INSTALL_DIR%\run_silent.vbs"

:: Create Uninstaller
(
echo @echo off
echo title Uninstall EPL 2026
echo color 0C
echo echo ====================================================
echo echo           Uninstall EPL 2026 Match Center
echo echo ====================================================
echo echo.
echo set /p CONFIRM="Are you sure you want to uninstall EPL 2026? (Y/N): "
echo if /i not "%%CONFIRM%%"=="Y" exit /b
echo.
echo Removing Desktop shortcut...
echo del /f /q "%%USERPROFILE%%\Desktop\EPL 2026.lnk" 2^>nul
echo Removing Start Menu shortcut...
echo del /f /q "%%APPDATA%%\Microsoft\Windows\Start Menu\Programs\EPL 2026.lnk" 2^>nul
echo Removing installation folder...
echo cd /d "%%LOCALAPPDATA%%\Programs"
echo rmdir /s /q "%%LOCALAPPDATA%%\Programs\EPL2026" 2^>nul
echo echo EPL 2026 has been successfully uninstalled.
echo pause
echo exit /b
) > "%INSTALL_DIR%\uninstall.bat"

echo [4/4] Creating Desktop and Start Menu Shortcuts...

:: Create temporary VBScript to make desktop & start menu shortcuts
(
echo Set WshShell = CreateObject^("WScript.Shell"^)
echo strDesktop = WshShell.SpecialFolders^("Desktop"^)
echo strPrograms = WshShell.SpecialFolders^("Programs"^)
echo strAppDir = "%INSTALL_DIR%"
echo.
echo ' Desktop shortcut
echo Set oLink = WshShell.CreateShortcut^(strDesktop ^& "\EPL 2026.lnk"^)
echo oLink.TargetPath = strAppDir ^& "\run_silent.vbs"
echo oLink.WorkingDirectory = strAppDir
echo oLink.Description = "EPL 2026 - Premier League Match Center"
echo If CreateObject^("Scripting.FileSystemObject"^).FileExists^(strAppDir ^& "\icon.ico"^) Then
echo     oLink.IconLocation = strAppDir ^& "\icon.ico, 0"
echo End If
echo oLink.Save
echo.
echo ' Start Menu shortcut
echo Set oStartLink = WshShell.CreateShortcut^(strPrograms ^& "\EPL 2026.lnk"^)
echo oStartLink.TargetPath = strAppDir ^& "\run_silent.vbs"
echo oStartLink.WorkingDirectory = strAppDir
echo oStartLink.Description = "EPL 2026 - Premier League Match Center"
echo If CreateObject^("Scripting.FileSystemObject"^).FileExists^(strAppDir ^& "\icon.ico"^) Then
echo     oStartLink.IconLocation = strAppDir ^& "\icon.ico, 0"
echo End If
echo oStartLink.Save
) > "%TEMP%\create_epl_shortcuts.vbs"

cscript //nologo "%TEMP%\create_epl_shortcuts.vbs"
del /f /q "%TEMP%\create_epl_shortcuts.vbs" 2>nul

echo.
echo ====================================================================
echo   SUCCESS! EPL 2026 HAS BEEN INSTALLED ON YOUR PC!
echo ====================================================================
echo.
echo - A shortcut "EPL 2026" is now on your Desktop.
echo - It is also added to your Windows Start Menu.
echo.
echo Launching EPL 2026 now...
wscript "%INSTALL_DIR%\run_silent.vbs"
timeout /t 3 >nul
exit /b 0
