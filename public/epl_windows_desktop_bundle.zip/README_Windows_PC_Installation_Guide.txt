========================================================================
EPL 2026 MATCH CENTER - WINDOWS PC INSTALLATION GUIDE
========================================================================

Method 1: 1-Click Automatic Installer
------------------------------------------------------------
1. Extract (unzip) this ZIP file on your computer.
2. Double-click "INSTALL_EPL2026_PC.bat".
3. The installer will automatically:
   - Install EPL 2026 to %LocalAppData%\Programs\EPL2026
   - Place a desktop shortcut named "EPL 2026" on your Desktop
   - Add "EPL 2026" to your Windows Start Menu
   - Launch the app in native frameless desktop app mode!

Method 2: Portable Mode (Run without installing)
------------------------------------------------------------
- Just double-click "Launch_EPL2026_Portable.bat" or open "index.html".
========================================================================